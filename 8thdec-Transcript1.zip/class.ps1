﻿class VM


{  

        $name
        [string]status()

        {
        returned "STOP"
        }



}